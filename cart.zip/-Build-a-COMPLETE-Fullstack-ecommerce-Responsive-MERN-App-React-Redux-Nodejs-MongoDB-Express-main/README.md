# -Build-a-COMPLETE-Fullstack-ecommerce-Responsive-MERN-App-React-Redux-Nodejs-MongoDB-Express
 Build a COMPLETE Fullstack ecommerce Responsive MERN App | React, Redux, Nodejs, MongoDB, Express

Backend Environment variables  : 

MONGODB_URL : ""
STRIPE_SECRET_KEY : "",
FRONTEND_URL : "",

MY Backend URL : https://backend-mern-kowt.onrender.com

start : 

## npm run dev 


Frontend Environment variables  :

REACT_APP_SERVER_DOMIN = <backend url>

REACT_APP_ADMIN_EMAIL = <admin email id >

REACT_APP_STRIPE_PUBLIC_KEY  = <stripe public key>

start : 

## npm start
 
 ## Full Video on Youtube : 
    Dynamic Coding with Amit
